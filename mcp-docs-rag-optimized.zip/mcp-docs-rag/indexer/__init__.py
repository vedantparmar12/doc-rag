"""Document indexing for fast search."""
