"""Search modules for MCP docs RAG."""
